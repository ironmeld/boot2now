
#define FOO \
	int a; \
	int b;

//FOO

#define BAR(A,B)  int A; double B;
