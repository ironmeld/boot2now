
#define A 1
#define B(X) ((X)+1)

#if B(2) == C
int y;
#else
double y;
#endif

