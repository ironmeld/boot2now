// pretty-print oddities

int foo(int x) {
  do { 
    x = x + 1;
  } while (x < 10);
}
