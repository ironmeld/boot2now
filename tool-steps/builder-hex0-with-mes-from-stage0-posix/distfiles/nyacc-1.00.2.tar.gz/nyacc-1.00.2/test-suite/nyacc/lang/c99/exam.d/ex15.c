#define FOO "inc.h"
#include FOO
