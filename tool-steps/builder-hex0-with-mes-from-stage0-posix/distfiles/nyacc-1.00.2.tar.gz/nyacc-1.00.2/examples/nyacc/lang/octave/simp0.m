function [c,d,e] = simp0(a, b)
  x = a + 1;
  y = b + 1;
  c = x * y;
  d = 1;
  e = 2;
end
