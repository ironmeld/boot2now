#ifndef EX14B_H
#define EX14B_H 1
#include "ex14a.h"
#endif
