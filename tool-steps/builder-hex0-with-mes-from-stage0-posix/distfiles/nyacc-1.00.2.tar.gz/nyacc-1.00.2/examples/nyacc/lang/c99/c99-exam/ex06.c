enum abc {
  A = 0,
  B,
  C } x;
