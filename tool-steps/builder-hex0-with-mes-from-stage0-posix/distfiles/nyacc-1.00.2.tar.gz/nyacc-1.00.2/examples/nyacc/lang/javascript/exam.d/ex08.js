// p 152 in JS-TDG
function Rectangle(w, h) {
  //this.width = w;
  //this.height = h;
  //this.area = function() { return this.width * this.height; }
  return w + h;
}
Rectangle(3, 4)
