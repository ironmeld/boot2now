
int foo(int k) {
  do {
    k = k + 1;
  } while (k < 10);
  return k;
}
