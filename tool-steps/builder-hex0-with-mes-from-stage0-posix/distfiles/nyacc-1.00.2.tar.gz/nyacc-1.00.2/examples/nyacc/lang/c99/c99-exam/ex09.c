int x1[3];
int x2[3][4];
