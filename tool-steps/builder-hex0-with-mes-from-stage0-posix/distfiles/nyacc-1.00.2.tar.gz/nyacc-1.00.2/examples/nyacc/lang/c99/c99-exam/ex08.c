int foo1(int y);
int foo2();
