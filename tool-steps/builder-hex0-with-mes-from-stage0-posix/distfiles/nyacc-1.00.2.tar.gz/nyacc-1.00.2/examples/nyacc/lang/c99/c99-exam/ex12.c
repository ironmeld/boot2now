typedef struct foo {
	int x; 
	/**
	 * A
 	 * B
	 */
	double y;
} foo_t;
