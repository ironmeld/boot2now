var uid = (function() { var id = 0; return function () { return id++; };})();
display(uid()); newline();
display(uid()); newline();
display(uid()); newline();
display(uid()); newline();
