struct A {} int i;
