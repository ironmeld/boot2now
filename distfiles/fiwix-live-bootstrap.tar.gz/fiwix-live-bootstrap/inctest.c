#include <fiwix/fs2.h>

void testfunc() {
}
