/*
 * fiwix/include/fiwix/video.h
 *
 * Copyright 2021, Jordi Sanfeliu. All rights reserved.
 * Distributed under the terms of the Fiwix License.
 */

#ifndef _FIWIX_VIDEO_H
#define _FIWIX_VIDEO_H

void video_init(void);

#endif /* _FIWIX_VIDEO_H */
